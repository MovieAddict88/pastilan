<?php
// backend/config.php

// YouTube Data API v3 key
// PLEASE NOTE: You should replace the value below with your own YouTube Data API key.
// For more information, see: https://developers.google.com/youtube/v3/getting-started
define('YOUTUBE_API_KEY', 'AIzaSyCuDFW3lSVrvc-nGUeQOkM7h_f_MA90NwY');
?>